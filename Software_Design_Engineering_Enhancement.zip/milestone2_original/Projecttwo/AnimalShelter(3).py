from pymongo import MongoClient

class AnimalShelter:
    """ CRUD operations for the Animal collection in MongoDB """

    def __init__(self, username, password):
        HOST = 'nv-desktop-services.apporto.com'
        PORT = 30363
        DB = 'AAC'
        COL = 'animals'

        # Use the provided username and password to connect
        self.client = MongoClient(f"mongodb://{username}:{password}@{HOST}:{PORT}/?authSource=admin")
        self.database = self.client[DB]
        self.collection = self.database[COL]

    def create(self, data):
        if data:
            try:
                self.collection.insert_one(data)
                return True
            except Exception as e:
                print(f"Insertion error: {e}")
                return False
        else:
            raise Exception("No data provided to insert")

    def read(self, query):
        try:
            return list(self.collection.find(query))
        except Exception as e:
            print(f"Read error: {e}")
            return []

    def update(self, query, update_values):
        try:
            result = self.collection.update_many(query, {'$set': update_values})
            return result.modified_count
        except Exception as e:
            print(f"Update error: {e}")
            return 0

    def delete(self, query):
        try:
            result = self.collection.delete_many(query)
            return result.deleted_count
        except Exception as e:
            print(f"Delete error: {e}")
            return 0